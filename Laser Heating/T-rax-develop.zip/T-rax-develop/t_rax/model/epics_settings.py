epics_settings = {
    'us_last_temp': '13IDD:us_las_temp',
    'ds_last_temp': '13IDD:ds_las_temp',
    'us_last_int': '13IDD:up_t_int',
    'ds_last_int': '13IDD:dn_t_int',
    'file_counter': '13IDD:t_counter',
    'T_folder': '13IDDLF1:cam1:FilePath_RBV',
}
