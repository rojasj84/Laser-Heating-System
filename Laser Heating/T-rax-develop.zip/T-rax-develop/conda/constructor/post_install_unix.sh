#/bin/bash

$PREFIX/bin/run_t_rax -m
